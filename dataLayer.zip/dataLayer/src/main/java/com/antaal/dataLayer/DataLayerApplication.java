package com.antaal.dataLayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataLayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLayerApplication.class, args);
	}

}
